let angle = 0;

function setup() {
  let canvas = createCanvas(windowWidth, windowHeight, WEBGL);
  canvas.parent('symbolicCanvas');
  noFill();
  stroke(255);
}

function draw() {
  background(10);
  rotateX(angle * 0.3);
  rotateY(angle * 0.2);
  strokeWeight(1.5);
  beginShape();
  for (let i = 0; i < TWO_PI; i += 0.1) {
    let x = 150 * sin(i * 3 + angle);
    let y = 150 * cos(i * 2 + angle);
    let z = 75 * sin(i + angle);
    vertex(x, y, z);
  }
  endShape(CLOSE);
  angle += 0.01;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}